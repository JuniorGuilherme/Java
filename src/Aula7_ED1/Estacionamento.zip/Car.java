package Aula7_ED1;

/**
 * Created by jrg_c on 06/09/2016.
 */
public class Car {
        String placa;
        int manobra;
}